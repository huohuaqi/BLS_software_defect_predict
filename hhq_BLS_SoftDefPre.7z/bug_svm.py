# 用LinearRegression，二分类，promise度量，F1
import numpy as np
from sklearn import svm
from sklearn.datasets  import load_digits
from sklearn.model_selection  import train_test_split
import matplotlib.pyplot as plt
import sys

# promise bug数据集
import tool_read_bug

def bug_svm(projectName, versions:list ):
    traindata,testdata,trainlabel,testlabel = None, None, None, None
    # projectName = "ant"
    # versions = [1.3, 1.4, 1.5, 1.6, 1.7]
    # projectName = "camel"
    # versions = [1.0, 1.2, 1.4, 1.6]
    arr1,traindata,trainlabel  = tool_read_bug.read_fn(projectName, versions[0], isPrint=False)
    for v in versions[1:]:
        arr1,arr2,arr3  = tool_read_bug.read_fn(projectName, v)
        traindata = np.vstack( (traindata, arr2) )
        trainlabel = np.hstack( (trainlabel, arr3) )

    traindata,testdata,trainlabel,testlabel = train_test_split(traindata,trainlabel,test_size=0.2,random_state=2021)

    # print(traindata.shape)
    # print(trainlabel.shape)
    # print(testdata.shape)

    # ll = 5
    # if ll == 5:
    #     sys.exit(0)

    x,test_x,y,test_y = traindata,testdata,trainlabel,testlabel

    labels=["LinearSVC", "NuSVC", "SVC"]
    res = [0, 0, 0]
    model = svm.LinearSVC( )
    model.fit(x, y)
    z = model.predict(test_x)
    res[0] =   np.sum(z==test_y)/z.size  
    print('准确率:', res[0])

    # model = svm.SVC()
    # model.fit(x, y)
    # z = model.predict(test_x)
    # res[2] =   np.sum(z==test_y)/z.size  
    # print('准确率:', res[2])



    import tool_f1
    F1 = tool_f1.myF1(z, test_y, 0.5, isPrint=False)
    print(projectName,"f1:", F1)
    if projectName in res_dict.keys():
        res_dict[projectName].append(F1)
    else:
        res_dict[projectName] = [ F1 ]


pNames = ['ant', 'camel', 'ivy', 'jedit', 'log4j', 'lucene', 'poi', 'synapse', 'velocity', 'xalan', 'xerces']
pVersions = [['1.3', '1.4', '1.5', '1.6', '1.7'],
    ['1.0', '1.2', '1.4', '1.6'],
    ['1.0', '1.1', '1.2'],
    ['3.2', '4.0', '4.1', '4.2', '4.3'],
    ['1.0', '1.1', '1.2'],
    ['2.0', '2.2', '2.4'],
    ['1.5', '2.0', '2.5', '3.0'],
    ['1.0', '1.1', '1.2'],
    ['1.4', '1.5', '1.6'],
    ['2.4', '2.5', '2.6', '2.7'],
    ['1.1', '1.2', '1.3', '1.4.4']]

res_dict = {}

p = 0
for projectName in pNames:
    for i in range(3):
        bug_svm(projectName, pVersions[p])
    p += 1

print(res_dict)

# F1-score: 0.759
"""
{'ant': [0.757081878152891, 0.7663297045101088, 0.7289012738853502], 
'camel': [0.6906090190609019, 0.6957623215108245, 0.6980654076462459],
 'ivy': [0.7618657937806874, 0.7381938690969346, 0.7412645590682195], 
 'jedit': [0.736090775988287, 0.7668338108882521, 0.7767792954708841], 
 'log4j': [0.7069199457259159, 0.7327127659574467, 0.7069199457259159], 
 'lucene': [0.7267573696145125, 0.7267573696145125, 0.733934611048478], 
 'poi': [0.7607788595271211, 0.7420878601794993, 0.74624765478424], 
 'synapse': [0.7694770544290289, 0.7267876200640342, 0.6995565410199556], 
 'velocity': [0.7760084925690022, 0.7613516367476242, 0.7694770544290288], 
 'xalan': [0.7494436201780414, 0.7475710014947683, 0.7506021863998517], 
 'xerces': [0.6929495202336254, 0.7039966694421315, 0.6679503637141635]}
"""