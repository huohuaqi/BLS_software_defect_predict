# 用LinearSVM，二分类，promise度量，F1
import numpy as np
from sklearn import svm
from sklearn.datasets  import load_digits
from sklearn.model_selection  import train_test_split
import matplotlib.pyplot as plt
import sys
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LogisticRegressionCV

# promise ast数据集
import tool_read_bug




def bug_lr(projectName, versions ):
    traindata,testdata,trainlabel,testlabel = None, None, None, None
    # projectName = "ant"
    # versions = [1.3, 1.4, 1.5, 1.6, 1.7]
    arr1,traindata,trainlabel  = tool_read_bug.read_fn(projectName, versions[0], isPrint=False)
    for v in versions[1:]:
        arr1,arr2,arr3  = tool_read_bug.read_fn(projectName, v)
        traindata = np.vstack( (traindata, arr2) )
        trainlabel = np.hstack( (trainlabel, arr3) )




    traindata,testdata,trainlabel,testlabel = train_test_split(traindata,trainlabel,test_size=0.2,random_state=2021)

    # print(traindata.shape)
    # print(trainlabel.shape)
    # print(testdata.shape)

    # ll = 5
    # if ll == 5:
    #     sys.exit(0)

    x,test_x,y,test_y = traindata,testdata,trainlabel,testlabel


    model = LogisticRegression(max_iter=3000)
    # model = LogisticRegressionCV(max_iter=3000)
    model.fit(traindata, trainlabel)

    z = model.predict(testdata)

    import tool_f1
    F1 = tool_f1.myF1(z, test_y, 0.5, isPrint=False)
    print(projectName,"f1:", F1)
    if projectName in res_dict.keys():
        res_dict[projectName].append(F1)
    else:
        res_dict[projectName] = [ F1 ]
    # F1-score: 0.7622511485451762

pNames = ['ant', 'camel', 'ivy', 'jedit', 'log4j', 'lucene', 'poi', 'synapse', 'velocity', 'xalan', 'xerces']
pVersions = [['1.3', '1.4', '1.5', '1.6', '1.7'],
    ['1.0', '1.2', '1.4', '1.6'],
    ['1.0', '1.1', '1.2'],
    ['3.2', '4.0', '4.1', '4.2', '4.3'],
    ['1.0', '1.1', '1.2'],
    ['2.0', '2.2', '2.4'],
    ['1.5', '2.0', '2.5', '3.0'],
    ['1.0', '1.1', '1.2'],
    ['1.4', '1.5', '1.6'],
    ['2.4', '2.5', '2.6', '2.7'],
    ['1.1', '1.2', '1.3', '1.4.4']]

res_dict = {}

p = 0
for projectName in pNames:
    for i in range(3):
        bug_lr(projectName, pVersions[p])
    p += 1

print(res_dict)
'''
{'ant': [0.7637130801687765, 0.7657518361035949, 0.7360346184107003], 
'camel': [0.695158675005791, 0.695158675005791, 0.7033547794117647], 
'ivy': [0.7669111654441729, 0.7587612061939689, 0.7422072451558552], 
'jedit': [0.7383997077091706, 0.7687590187590186, 0.7709758732445084], 
'log4j': [0.712691771269177, 0.7354570637119113, 0.7317415730337078], 
'lucene': [0.7080957810718358, 0.7080957810718358, 0.7226606538895152], 
'poi': [0.7657061880018895, 0.7551020408163266, 0.751564756860857], 
'synapse': [0.7468487394957983, 0.7085533262935586, 0.6699029126213593], 
'velocity': [0.7824709609292503, 0.7678571428571429, 0.7760084925690022], 
'xalan': [0.7496696243156504, 0.7458626593113943, 0.7482570190314679], 
'xerces': [0.6900706273369339, 0.7081598667776853, 0.6707679253288079]}


'''
    