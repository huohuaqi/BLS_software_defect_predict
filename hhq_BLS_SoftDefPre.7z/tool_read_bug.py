
import sys, os
import csv 
import numpy as np
import random
base_dir = "./promise_dataset" + "/"
# E:/Documents/backup/postGraduate_1/third_projects/PROMISE-backup/bug-data

# projectName / projectName-Version.csv

random.seed(2021)

# 归一化
def standardization(data):
    mu = np.mean(data, axis=0)
    sigma = np.std(data, axis=0) + 1
    return (data - mu) / sigma


def read_fn(projectName, version, isPrint=True):
    version = str(version)
    fn =base_dir + projectName +"/"+ projectName + "-" + version + ".csv"
    with open(fn, 'r', encoding="utf-8") as f:
        lines = f.readlines()
    arr1_name = []
    arr2_attr = []
    arr3_label = []
    for line in lines[1:]:
        line = line.strip()
        attrs = line.split(",")
        length = len(attrs)
        arr1_name.append(attrs[0])
        arr2_attr.append(attrs[1:length-1])
        arr3_label.append(attrs[length-1])
    arr2_attr = np.asarray(arr2_attr, dtype=float)

    # 让有标签大于1的 等于1
    index = 0
    for i in arr3_label:
        if int(i) != 0:
            arr3_label[index] = 1
        index += 1
    # 标签转为整数numpy
    arr3_label = np.asarray(arr3_label, dtype=int)
    

    # 归一化
    arr2_attr = standardization(arr2_attr)

    # 删除某些属性
    # del_obj = [ 5 , 8,  12, 13, 14]  # 5  8  12 13 14
    # arr2_attr = np.delete(arr2_attr, del_obj, 1)

    # 增加正样本
    t,f = 0,0
    positiveIndexs = [] # 正样本的下标
    index = 0
    for i in arr3_label:
        if i == 0:
            f+=1
        else:
            t+=1
            positiveIndexs.append(index)
        index += 1
    # print(t+f, t, f)
    # print(positiveIndexs,  "-> 正样本的下标")
    while( t < f ):
        twoIndexs = random.sample(positiveIndexs, 2)
        a1 = arr2_attr[twoIndexs[0]]
        a2 = arr2_attr[twoIndexs[1]]
        a3 = (a1+a2) / 2
        arr2_attr = np.append(arr2_attr, a3.reshape(1,-1), axis=0)
        t+=1
        arr3_label = np.append(arr3_label, [1], axis=0)

    # print(arr2_attr)
    # print(arr3_label)
    if isPrint:
        print(projectName+"-"+version,":", len(arr1_name), arr2_attr.shape, arr3_label.shape)
    return arr1_name, arr2_attr, arr3_label





if __name__ == "__main__":
    a,b,c = read_fn("ant", 1.3)
    print(b[200])
    print(c)
    