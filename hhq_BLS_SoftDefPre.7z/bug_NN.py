# 用 Neural Network，二分类，promise度量，F1
import numpy as np
from sklearn import svm
from sklearn.datasets  import load_digits
from sklearn.model_selection  import train_test_split
import matplotlib.pyplot as plt
import sys
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LogisticRegressionCV
from sklearn.preprocessing import OneHotEncoder

from tensorflow.keras import models
from tensorflow.keras import layers
from tensorflow.keras import optimizers
from tensorflow.keras import losses
from tensorflow.keras import metrics
from tensorflow import keras

# promise bug数据集
import tool_read_bug

def bug_NN(projectName, versions):
    traindata,testdata,trainlabel,testlabel = None, None, None, None
    # projectName = "ant"
    # versions = [1.3, 1.4, 1.5, 1.6, 1.7]
    # projectName = "camel"
    # versions = [1.0, 1.2, 1.4, 1.6]
    arr1,traindata,trainlabel  = tool_read_bug.read_fn(projectName, versions[0], isPrint=False)
    for v in versions[1:]:
        arr1,arr2,arr3  = tool_read_bug.read_fn(projectName, v)
        traindata = np.vstack( (traindata, arr2) )
        trainlabel = np.hstack( (trainlabel, arr3) )

    trainlabel = trainlabel.reshape(-1, 1)
    enc = OneHotEncoder()
    enc.fit(trainlabel)
    trainlabel = enc.transform(trainlabel).toarray()


    traindata,testdata,trainlabel,testlabel = train_test_split(traindata,trainlabel,test_size=0.2,random_state=2021)

    print(traindata.shape)
    print(trainlabel.shape)
    print(testdata.shape)
    # print(trainlabel)

    # ll = 5
    # if ll == 5:
    #     sys.exit(0)

    x,test_x,y,test_y = traindata,testdata,trainlabel,testlabel



    # 使用Sequential类定义两层模型
    N_len = x.shape[1]
    # 是否训练
    Train = 1
    if Train == 1:
        model = models.Sequential()
        model.add(layers.Dense(20, input_shape=(N_len,)))  # 
        model.add(layers.LeakyReLU(0.1))
        model.add(layers.Dropout(0.3))
        model.add(layers.Dense(16 ))
        model.add(layers.LeakyReLU(0.1))
        model.add(layers.Dropout(0.3))
        model.add(layers.Dense(8 ))
        model.add(layers.LeakyReLU(0.1))
        model.add(layers.Dense(2, activation='softmax'))

        model.compile(optimizer=optimizers.RMSprop(lr=0.001),
                    loss=losses.categorical_crossentropy,
                    metrics=[metrics.categorical_accuracy])
        model.fit(x, y, batch_size=100, epochs=20)
        # model.save("./models/bug_NN_1.h5")
    else:
        model = keras.models.load_model("./models/bug_NN_1.h5")
        model.fit(x, y, batch_size=128, epochs=20)
        model.save("./models/bug_NN_1.h5")

    z = model.predict(testdata)
    loss, acc = model.evaluate(testdata, testlabel)
    print("result:", loss, acc) # result: 0.4558475613594055 0.815642476081848


    pre_label = np.argmax(z, axis=1) 
    real_label = np.argmax(testlabel, axis=1) 


    import tool_f1
    F1 = tool_f1.myF1(pre_label, real_label, 0.5, isPrint=False)
    print(projectName,"f1:", F1)
    if projectName in res_dict.keys():
        res_dict[projectName].append(F1)
    else:
        res_dict[projectName] = [ F1 ]

    # F1-score: 0.8214535290006988


pNames = ['ant', 'camel', 'ivy', 'jedit', 'log4j', 'lucene', 'poi', 'synapse', 'velocity', 'xalan', 'xerces']
pVersions = [['1.3', '1.4', '1.5', '1.6', '1.7'],
    ['1.0', '1.2', '1.4', '1.6'],
    ['1.0', '1.1', '1.2'],
    ['3.2', '4.0', '4.1', '4.2', '4.3'],
    ['1.0', '1.1', '1.2'],
    ['2.0', '2.2', '2.4'],
    ['1.5', '2.0', '2.5', '3.0'],
    ['1.0', '1.1', '1.2'],
    ['1.4', '1.5', '1.6'],
    ['2.4', '2.5', '2.6', '2.7'],
    ['1.1', '1.2', '1.3', '1.4.4']]

res_dict = {}

PreStop = 0
p = 0
for projectName in pNames:
    if p<PreStop:
        p += 1
        continue
    
    for i in range(3):
        bug_NN(projectName, pVersions[p])
        print("当前p=", p)
        print(res_dict)
    p += 1

print(res_dict)
'''
当前p= 2
{'ant': [0.8054378531073447, 0.7940650697175544, 0.7925819229384228], 
'camel': [0.77552400270453, 0.7672182468694096, 0.7451200358985866], 
'ivy': [0.7700077700077701, 0.79491133384734, 0.7595846645367412],
'jedit': [0.795566502463054, 0.8147226173541963, 0.7687590187590186],
'log4j': [0.7444589308996089, 0.7750906892382103, 0.7508650519031141],
'lucene': [0.7012835472578763, 0.75802752293578, 0.7103365384615384],
'poi': [0.7568981921979069, 0.7616555661274976, 0.7616555661274976], 
'synapse': [0.7414163090128756, 0.7123142250530785, 0.7331995987963892], 
'velocity': [0.7518315018315018, 0.7448210922787194, 0.7517667844522968], 
'xalan': [0.7390012994245405, 0.7342564491654022, 0.7397127329192545], 
'xerces': [0.7202849643794527, 0.6732473811442384, 0.6949941792782305]
}

'''