import numpy as np

def myF1( z, label,  threshold=0.5, isPrint=True):
    print("------------\ntest的评估:")
    y_predict = z
    if isPrint:
        print( z[:20])
        print(label[:20]) 
    y_predict = np.ravel(y_predict) 

    length = y_predict.shape[0]
    TP = 0.1
    FP = 0.1
    FN = 0.1
    TN = 0.1
    cou = 0
    for i in range(length):
        if y_predict[i]> threshold :
            y_predict[i] = 1
            cou += 1
        else:
            y_predict[i] = 0
    if isPrint:
        print("大于阈值的有N个，N=", cou)
    for i in range(length):
        if label[i]==1 and y_predict[i]==1:
            TP += 1 
        elif label[i]==1 and y_predict[i]==0:
            FN += 1 
        elif label[i]==0 and y_predict[i]==1:
            FP += 1 
        else:
            TN += 1 
    
    prec = TP/(TP+FP)
    recall = TP/(TP+FN)
    F1  = 2*prec*recall/(prec+recall)
    if isPrint:
        print("都真", TP, "假成真",FP, "真预假",FN, "都假",TN)
        print("precision:", prec)
        print("recall:", recall)
        print("F1-score:", )
    return F1
    